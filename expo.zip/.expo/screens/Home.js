import React from 'react';
import { StyleSheet, Text, Image, TouchableOpacity, View } from 'react-native';
import bike1 from '../bike1.png';
import bike2 from '../bike2.png';
import bike5 from '../bike5.png';
import bike4 from '../bike4.png';

export {
  bike1,
  bike2,
  bike5,
  bike4,
}



export default function Home(params) {
    const navigation = params.navigation;

  return (
    <View style={styles.container}>


      



      <View style={{flexDirection: 'row'}}>
        <Text style={styles.text1}>The World's</Text>
        <Text style={styles.text2}>Best Bike</Text>
      </View>

      <Text style={styles.categories}>Categories</Text>


      <View style={{flexDirection: 'row', justifyContent: 'space-between', width: 400, marginBottom: 20} }>

        <TouchableOpacity style={styles.button1}>
            <Text style={styles.button1Text}>All</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button1}>
            <Text style={styles.button2Text}>RoadBike</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button1}>
            <Text style={styles.button2Text}>Mountain</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button1}>
            <Text style={styles.button2Text}>Urban</Text>
        </TouchableOpacity>
       
      </View>
  

      <View style={{flexDirection: 'row', height: '35%', width: '100%', justifyContent: 'space-between', marginBottom: 15}}>
        <View style={styles.bikeView1}>
          <Image  style={styles.imageStyle}
              source={bike1}
          />
          <View style={{top: 40}}>
            <Text>Pinarello Bike</Text>
            <Text>$5,000</Text>
          </View>
        </View>
        <View style={styles.bikeView2}>
          <Image  style={styles.imageStyle}
              source={bike2}
          />
          
          <View style={{top: 40}}>
            <Text>Pinarello Bike</Text>
            <Text>$7,000</Text>
          </View>
        </View>
       
      </View>

      <View style={{flexDirection: 'row', height: '35%', width: '100%', justifyContent: 'space-between'}}>
        <View style={styles.bikeView1}>
          <Image style={styles.imageStyle}
              source={bike5}
          />
           <View style={{top: 40}}>
            <Text>Pinarello Bike</Text>
            <Text>$4,200</Text>
          </View>
        </View>
        <View style={styles.bikeView2}>
          <Image style={styles.imageStyle}
              source={bike4}
          />
         <View style={{top: 40}}>
            <Text>Pinarello Bike</Text>
            <Text>$3,700</Text>
          </View>
        </View>
       
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 18,
    backgroundColor: '#fff',
  },
  text1: {
      fontSize: 25,
      color: `#585858`,
      marginRight: 5,
  },
  text2: {
    fontSize: 25,
    marginBottom: 20,
    fontWeight: "700",
    color: `#ffd916`,
  },
  categories: {
    fontSize: 23,
    fontWeight: '700',
    marginBottom: 12,
  },
  button1: {
    backgroundColor: `#F8F8F8`,
    paddingTop: 10,
    paddingRight: 20,
    paddingLeft: 20,
    paddingBottom: 10,
    borderRadius: 10,
    justifyContent: 'center',
  },
  bikeView1: {
    backgroundColor: `#F8F8F8`,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    width: '47%',
    height: '100%',
    marginRight: 5,
  },
  bikeView2: {
    justifyContent: 'center',
    backgroundColor: `#F8F8F8`,
    padding: 10,
    alignItems: 'center',
    borderRadius: 20,
    width: '47%',
    height: '100%',
  },
  button1Text: {
    color: `#ffd916`,
    fontSize: 18,
  },
  button2Text: {
    color: `#585858`,
    fontSize: 18,
  },
  imageStyle: {
    width: "100%",
    height: '38%',
    marginBottom: 20,
  },
});