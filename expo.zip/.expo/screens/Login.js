import React from 'react';
import { StyleSheet, Text, Image, TouchableOpacity, View } from 'react-native';
import { AntDesign } from "@expo/vector-icons";
import image from "./image.jpg";
import * as Font from 'expo-font';
import { useFonts } from 'expo-font';




export default function Login(params) {
    const navigation = params.navigation;
    const [loaded] = useFonts({
      Poppins: require('../assets/Poppins/Poppins-Regular.ttf'),
    })

  return (
    <View style={styles.container}>


        <Image
            style={styles.imageStyle}
            source={image}
        />



      <Text style={styles.text1}>Welcome to</Text>
      <Text style={styles.text2}>Power Bike Shop</Text>

      <TouchableOpacity style={styles.button1} onPress={() => {
            navigation.navigate("Home")
        }}>
          <AntDesign name="google" size={24} color="blue" />
          <Text style={styles.button1Text}>Login with Gmail</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button2}>
          <AntDesign name="apple1" size={24} color="white" marginRight="5"/>
          <Text style={styles.button2Text}>Login with Apple</Text>
      </TouchableOpacity>

        <Text>Not a member, Sign Up</Text>

    </View>
  );
}

const styles = StyleSheet.create({
  
  container: {
    flex: 1,
    fontFamily: 'Poppins',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text1: {
      fontSize: 35,
      color: `#585858`,
  },
  text2: {
    fontSize: 45,
    fontWeight: "700",
    marginBottom: 15,
  },
  button1: {
    flexDirection: 'row',
    backgroundColor: `#DCDCDC`,
    padding: 15,
    borderRadius: 10,
    justifyContent: 'center',
    width: 280,
    margin: 15,
  },
  button2: {
    flexDirection: 'row',
    backgroundColor: 'black',
    justifyContent: 'center',
    padding: 15,
    borderRadius: 10,
    width: 280,
  },
  button1Text: {
    color: `#585858`,
    fontSize: 22,
    marginLeft: 7,
  },
  button2Text: {
    color: '#fff',
    fontSize: 22,
    marginLeft: 7,
  },
  imageStyle: {
    transform: [{ rotate: "-45deg" }],
    borderRadius: 20,
    marginBottom: 60,
    width: 200,
    height: 200,
  },
});
